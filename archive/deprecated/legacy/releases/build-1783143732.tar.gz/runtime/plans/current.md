# Goal


# Tasks
1. Design architecture
2. Generate APIs
3. Generate frontend
4. Generate tests
5. Deploy
