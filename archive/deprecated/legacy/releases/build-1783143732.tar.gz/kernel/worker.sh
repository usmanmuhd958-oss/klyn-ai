#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

JOB_ID="$1"
TASK="$2"

echo "[WORKER] Job=$JOB_ID Task=$TASK"

curl -fsS \
  -X PATCH \
  -H "apikey: $SUPABASE_SERVICE_ROLE_KEY" \
  -H "Authorization: Bearer $SUPABASE_SERVICE_ROLE_KEY" \
  -H "Content-Type: application/json" \
  -d '{"status":"completed"}' \
  "$SUPABASE_URL/rest/v1/job_queue?id=eq.$JOB_ID"
