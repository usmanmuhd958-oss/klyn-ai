	#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

source .env

MAX_WORKERS=3
ACTIVE_WORKERS=0

LOG() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] [SCHEDULER] [$1] $2"
}

fetch_jobs() {
  curl -sS \
    -H "apikey: $SUPABASE_ANON_KEY" \
    -H "Authorization: Bearer $SUPABASE_ANON_KEY" \
    "${SUPABASE_URL}/rest/v1/jobs?status=eq.pending&limit=5"
}

LOG "BOOT" "Scheduler started"

while true; do

  # cleanup finished workers
  wait -n 2>/dev/null || true

  ACTIVE_WORKERS=$(jobs -rp | wc -l)

  if [[ "$ACTIVE_WORKERS" -ge "$MAX_WORKERS" ]]; then
    LOG "THROTTLE" "Max workers reached ($MAX_WORKERS)"
    sleep 2
    continue
  fi

  JOBS=$(fetch_jobs)

  if [[ "$JOBS" == "[]" || -z "$JOBS" ]]; then
    sleep 3
    continue
  fi

  # Extract first job safely (simplified parser)
  TASK_ID=$(echo "$JOBS" | grep -o '"id":[0-9]*' | head -n1 | cut -d: -f2)
  TASK_PAYLOAD=$(echo "$JOBS" | grep -o '"task":"[^"]*"' | head -n1 | cut -d: -f2 | tr -d '"')

  if [[ -z "$TASK_ID" ]]; then
    LOG "ERROR" "Failed to parse job"
    sleep 2
    continue
  fi

  LOG "DISPATCH" "Job $TASK_ID -> worker"

  # Spawn worker safely
  ./kernel/worker.sh "$TASK_ID" "$TASK_PAYLOAD" &
done
